1. extract zip file
2. open the folder in vs code 
3. open new terminal in vs code type (npm install) then (npm start)

(time to build this project:

15 working hrs
and I study react 3~4 days 

)
