import React from 'react';

const Header = () => {
  return <h1 className="main-heading">Spotify Artist Search</h1>;
};

export default Header;
